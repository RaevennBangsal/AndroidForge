# TAGNAWA / Lingayen Volunteerism System

This package contains:

1. `web/` — enhanced management/public prototype with real Web NFC support when opened on a supported Android browser over HTTPS.
2. `android/` — Android Studio source for a native TAGNAWA NFC Writer app using Android NFC APIs and NDEF text records.
3. `web/sample-id-reference.jpg` — the supplied sample ID reference.

## NTAG213 payload
The system writes only a short identifier such as:

`TAGNAWA:S10012`

Personal and emergency-contact information stays in the database and is not written to the NFC sticker.

## Real phone writing
For the web version, use Chrome on an NFC-enabled Android phone and serve the site over HTTPS. Web NFC support is browser/device dependent.

For the native Android project, open `android/` in Android Studio, build/install it on an NFC-capable Android phone, enter a Volunteer ID, press WRITE NFC, and tap the NTAG213 sticker.

## Production architecture
Desktop/web management system -> volunteer database -> ID printer -> NTAG213 -> Android NFC Writer -> event attendance scanner.

The current web prototype still uses localStorage for demonstration. A production deployment should use a secure backend/database, authentication, audit logs, server-side ID generation, encrypted transport, and role-based access control.
