package com.tagnawa.nfcwriter

import android.app.Activity
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import java.nio.charset.Charset

class MainActivity : Activity() {
    private var nfcAdapter: NfcAdapter? = null
    private var pendingPayload = "TAGNAWA:S10012"
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,32,32,32) }
        val title = TextView(this).apply { text = "TAGNAWA NFC WRITER"; textSize = 26f; setTextColor(Color.rgb(8,59,99)); gravity = Gravity.CENTER }
        val subtitle = TextView(this).apply { text = "NTAG213 • 13.56 MHz"; textSize = 15f; gravity = Gravity.CENTER; setPadding(0,10,0,25) }
        val input = EditText(this).apply { hint = "Volunteer ID (e.g. S10012)"; setSingleLine(true) }
        val write = Button(this).apply { text = "WRITE NFC" }
        status = TextView(this).apply { text = "Ready. Enter a Volunteer ID and tap WRITE NFC."; textSize = 16f; setPadding(0,25,0,0) }
        write.setOnClickListener { val id=input.text.toString().trim(); if(id.isNotEmpty()){ pendingPayload="TAGNAWA:$id"; status.text="Hold the NTAG213 sticker near the back of the phone..." } }
        root.addView(title); root.addView(subtitle); root.addView(input); root.addView(write); root.addView(status)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); val adapter=nfcAdapter ?: return; adapter.enableForegroundDispatch(this, android.app.PendingIntent.getActivity(this,0,android.content.Intent(this,javaClass).addFlags(android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP), android.app.PendingIntent.FLAG_MUTABLE), null, null) }
    override fun onPause() { nfcAdapter?.disableForegroundDispatch(this); super.onPause() }

    override fun onNewIntent(intent: android.content.Intent) { super.onNewIntent(intent); if(intent.action==NfcAdapter.ACTION_TAG_DISCOVERED || intent.action==NfcAdapter.ACTION_NDEF_DISCOVERED || intent.action==NfcAdapter.ACTION_TECH_DISCOVERED){ writeTag(intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)) } }

    private fun writeTag(tag: Tag?) {
        if(tag==null) return
        try {
            val ndef=Ndef.get(tag) ?: throw Exception("This tag is not NDEF-compatible")
            val text=payloadRecord(pendingPayload)
            val message=NdefMessage(arrayOf(text))
            ndef.connect()
            if(!ndef.isWritable) throw Exception("NFC tag is read-only")
            if(ndef.maxSize < message.toByteArray().size) throw Exception("Not enough NFC memory")
            ndef.writeNdefMessage(message)
            ndef.close()
            status.text="✓ NFC WRITTEN SUCCESSFULLY\nPayload: $pendingPayload\n\nRemove the card, then tap again to verify."
        } catch(e:Exception){ status.text="⚠ NFC write failed: ${e.message}" }
    }

    private fun payloadRecord(text:String): NdefRecord {
        val lang="en".toByteArray(Charset.forName("US-ASCII")); val body=text.toByteArray(Charset.forName("UTF-8")); val data=ByteArray(1+lang.size+body.size); data[0]=lang.size.toByte(); System.arraycopy(lang,0,data,1,lang.size); System.arraycopy(body,0,data,1+lang.size,body.size)
        return NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT, ByteArray(0), data)
    }
}
